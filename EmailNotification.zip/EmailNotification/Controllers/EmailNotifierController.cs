﻿using EmailNotification.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Common.Helpers;
using EmailNotofication.Models;
using System;
using System.Threading.Tasks;
using System.Web.Http;

namespace EmailNotification.Controllers
{
    public class EmailNotifierController : ApiController
    {
        TeamGroupA[] teamA = new TeamGroupA[] 
        { 
            new TeamGroupA { Id = 1, Name = "zing", Type = "Cricket", Price = 1 }, 
            new TeamGroupA { Id = 2, Name = "Yo-yo", Type = "Football", Price = 3.75M }, 
            new TeamGroupA { Id = 3, Name = "soft", Type = "Software", Price = 16.99M } 
        };

        // Run the application
        public IEnumerable<TeamGroupA> GetAllTeams()
        {
            return teamA;
        }

        [HttpPost]
        public async Task<IHttpActionResult> SendEmailNotification(EmailInput data)
        {
            ResponseBase updateResponse = new ResponseBase();
            var updateRequest = new RequestBase<EmailInput>(data);
            try
            {
                EMailHelper mailHelper = new EMailHelper(EMailHelper.EMAIL_SENDER, EMailHelper.EMAIL_CREDENTIALS, EMailHelper.SMTP_CLIENT);
                var emailBody = String.Format(EMailHelper.EMAIL_BODY);
                if (mailHelper.SendEMail(data.EmailId, EMailHelper.EMAIL_SUBJECT, emailBody))
                {
                     // 
                }
            }
            catch (Exception ex)
            {
                
            }
            return Ok(updateResponse);
        }

    }
}
