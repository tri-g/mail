﻿using System;

namespace EmailNotofication.Models
{
    public class EmailInput
    {
        public string UserName { get; set; }
        public string EmailId { get; set; }
    }
}